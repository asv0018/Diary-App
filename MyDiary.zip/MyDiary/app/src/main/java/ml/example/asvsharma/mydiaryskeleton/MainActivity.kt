package com.example.bitamirshafiee.mydiaryskeleton

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class MainActivity : AppCompatActivity() {
private val SPLASH_TIMEOUT= 3000L
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_main)
        Handler().postDelayed(
            {
                val intent = Intent(this@MainActivity, DiaryActivity::class.java)
                startActivity(intent)
                finish()
            }, SPLASH_TIMEOUT
        )
    }
}
