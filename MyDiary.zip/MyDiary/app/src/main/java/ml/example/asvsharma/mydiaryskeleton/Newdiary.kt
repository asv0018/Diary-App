package com.example.bitamirshafiee.mydiaryskeleton

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.media.AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Vibrator
import android.provider.BaseColumns._ID
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Toast
import com.example.bitamirshafiee.mydiaryskeleton.data.Databasemanager.DiaryEntry.COLUMN_DATE
import com.example.bitamirshafiee.mydiaryskeleton.data.Databasemanager.DiaryEntry.COLUMN_DIARY
import com.example.bitamirshafiee.mydiaryskeleton.data.Databasemanager.DiaryEntry.COLUMN_TITLE
import com.example.bitamirshafiee.mydiaryskeleton.data.Databasemanager.DiaryEntry.TABLE_NAME
import com.example.bitamirshafiee.mydiaryskeleton.data.Diarydbhelper

import kotlinx.android.synthetic.main.activity_newdiary.*
import kotlinx.android.synthetic.main.recycler_view_item.*
import java.text.SimpleDateFormat
import java.util.*

@Suppress("DEPRECATION")
class Newdiary : AppCompatActivity() {
private var id =0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_newdiary)
id=intent.getIntExtra("IDofRow",0)
        Log.d("NewDiary","$id")
if(id!=0){
    readDiary(id)
}
        val currentDate=SimpleDateFormat("EEE,d MMM yyyy")
        date.text=currentDate.format(Date())
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater =menuInflater
        inflater.inflate(R.menu.actionbar_menu,menu)
        return true
    }
    private fun readDiary(id:Int){
        val mdbHelper=Diarydbhelper(this)
        val db=mdbHelper.readableDatabase
        val projection= arrayOf(COLUMN_DATE,COLUMN_TITLE,COLUMN_DIARY)
        val selection= "$_ID = ?"
        val seletionArgs= arrayOf("$id")
        val cursor: Cursor =db.query(
            TABLE_NAME,
            projection,
            selection,
            seletionArgs,
            null,
            null,
            null
        )
val dateColumnIndex=cursor.getColumnIndexOrThrow(COLUMN_DATE)
        val titleColumnIndex=cursor.getColumnIndex(COLUMN_TITLE)
        val diaryColumnIndex=cursor.getColumnIndexOrThrow(COLUMN_DIARY)
        while(cursor.moveToNext()){
            val currentDate=cursor.getString(dateColumnIndex)
            val currentTitle=cursor.getString(titleColumnIndex)
            val currentDiary=cursor.getString(diaryColumnIndex)
            date.text=currentDate
            title_.setText(currentTitle)
            texxt.setText(currentDiary)
        }
        cursor.close()
    }
    private fun insertDiary(){
        val dateString=date.text.toString()
        val titleString=title_.text.toString().trim(){it <= ' '}
        val diaryString=texxt.text.toString().trim(){it <= ' '}
        val mdbhelper=Diarydbhelper(this)
        val db=mdbhelper.writableDatabase
        val values=ContentValues().apply {
            put(COLUMN_DATE,dateString)
            put(COLUMN_TITLE,titleString)
            put(COLUMN_DIARY,diaryString)
        }
       var id= db.insert(TABLE_NAME,null,values)
        val vibratorService = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if(id.equals(-1)){

            Toast.makeText(this,"problem in inserting",Toast.LENGTH_SHORT).show()
            //vibratorService.vibrate(500)
        }else{
            Log.d("check","here")
            Toast.makeText(this,"kudos! your feelings are saved!...",Toast.LENGTH_SHORT).show()
            vibratorService.vibrate(70)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when(item?.itemId){
            R.id.savediary->{
                if(id==0){
                    insertDiary()
                }else{
                    updateDiary(id)
                }
                finish()
                true
            }
            else->super.onOptionsItemSelected(item)
        }
    }


    override fun onBackPressed() {
        super.onBackPressed()
                if (id == 0) {
                    insertDiary()
                } else {
                    updateDiary(id)
                }
            }


    private fun updateDiary(id:Int){
        val mdbhelper= Diarydbhelper(this)
        val db=mdbhelper.writableDatabase
        val values=ContentValues().apply {
            put(COLUMN_TITLE,title_.text.toString())
            put(COLUMN_DIARY,texxt.text.toString())
        }
        db.update(TABLE_NAME,values,"$_ID=$id",null)

    }
}
