package com.example.bitamirshafiee.mydiaryskeleton

import android.content.Context
import android.content.Intent
import android.os.Vibrator
import android.provider.BaseColumns._ID
import android.support.v4.content.ContextCompat.getSystemService
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.bitamirshafiee.mydiaryskeleton.data.Databasemanager.DiaryEntry.TABLE_NAME
import com.example.bitamirshafiee.mydiaryskeleton.data.Diary
import com.example.bitamirshafiee.mydiaryskeleton.data.Diarydbhelper
import kotlinx.android.synthetic.main.recycler_view_item.view.*

class DiaryAdapter(private var diaryList:MutableList<Diary>):
    RecyclerView.Adapter<DiaryAdapter.DiaryViewHolder>() {

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): DiaryAdapter.DiaryViewHolder {
    val context=p0.context
        val inflater=LayoutInflater.from(context)
        val shouldAttachToParentImmediatly=false
        val view=inflater.inflate(R.layout.recycler_view_item,p0,shouldAttachToParentImmediatly)
        view.id_del.setOnClickListener{
            val mdbhelper=Diarydbhelper(view.context)
            val db=mdbhelper.writableDatabase
            val selection="$_ID=?"
            val selectionArgs= arrayOf("${(diaryList[p1].id)}")
            db.delete(TABLE_NAME,selection,selectionArgs)
            diaryList.removeAt(p1)
            notifyDataSetChanged()
        }
        return DiaryViewHolder(view)
    }

    override fun getItemCount(): Int {
   return diaryList.size
    }

    override fun onBindViewHolder(p0: DiaryAdapter.DiaryViewHolder, p1: Int) {
     val item=diaryList[p1]
        p0.bindDiary(item)
    }


    class DiaryViewHolder(v: View):RecyclerView.ViewHolder(v),View.OnClickListener{
        private var view:View
        private lateinit var diary: Diary
        private lateinit var date: TextView
        private lateinit var title: TextView
        init {
            view=v
            date=view.findViewById(R.id.datetext)
            title=view.findViewById(R.id.titletext)
            v.setOnClickListener(this)
        }
        fun bindDiary(diary: Diary){
            this.diary=diary
            date.text=diary.date
            title.text=diary.title

        }

        override fun onClick(v: View?) {
                val context=itemView.context
                val intent= Intent(context,Newdiary::class.java)
                intent.putExtra("IDofRow",diary.id)
                context.startActivity(intent)

        }
    }

}