package com.example.bitamirshafiee.mydiaryskeleton.data

data class Diary (var id: Int,var date:String,var title:String ,var diary:String)